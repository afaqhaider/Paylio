import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../Core/settings_provider.dart';
import '../Transactions/transaction_model.dart';
import '../Transactions/transaction_provider.dart';
import '../Transactions/add_expense_screen.dart';
import 'person_model.dart';
import 'person_provider.dart';

class PersonDetailScreen extends StatelessWidget {
  final PersonModel person;

  const PersonDetailScreen({super.key, required this.person});

  Map<String, double> _calculateSummary(PersonModel person, List<TransactionModel> transactions) {
    double lent = 0;
    double borrowed = 0;
    double repaidReceived = 0;
    double repaidPaid = 0;

    for (var tx in transactions) {
      if (tx.status != 'approved' && tx.status != 'confirmed') continue;
      
      // Match by either local id or shared paylioId
      bool matches = false;
      if (person.id != null && tx.personId == person.id) matches = true;
      if (person.paylioId != null && tx.personId == person.paylioId) matches = true;

      if (matches) {
        final type = tx.type.toLowerCase();
        if (type == 'lend' || type == 'loan_given') {
          lent += tx.amount;
        } else if (type == 'borrow' || type == 'loan_received') {
          borrowed += tx.amount;
        } else if (type == 'repayment_received') {
          repaidReceived += tx.amount;
        } else if (type == 'repayment_paid' || type == 'repayment_sent') {
          repaidPaid += tx.amount;
        }
      }
    }

    return {
      'lent': lent,
      'borrowed': borrowed,
      'repaidReceived': repaidReceived,
      'repaidPaid': repaidPaid,
      'netBalance': (lent - repaidReceived) - (borrowed - repaidPaid),
    };
  }

  @override
  Widget build(BuildContext context) {
    final txProvider = Provider.of<TransactionProvider>(context);
    final currency = Provider.of<SettingsProvider>(context).currency;
    final format = NumberFormat('#,##0.00');

    final personTransactions = txProvider.transactions.where((tx) {
      if (person.id != null && tx.personId == person.id) return true;
      if (person.paylioId != null && tx.personId == person.paylioId) return true;
      return false;
    }).toList();
    
    final summary = _calculateSummary(person, txProvider.transactions);
    final netBalance = summary['netBalance'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(person.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () {
              // Implementation for editing person name/details
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _buildHeader(summary, netBalance, currency, format),
          Expanded(
            child: personTransactions.isEmpty
                ? const Center(child: Text('No transactions yet', style: TextStyle(color: Colors.grey)))
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: personTransactions.length,
                    itemBuilder: (context, index) {
                      final tx = personTransactions[index];
                      return _buildTransactionCard(context, tx, currency, format);
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddExpenseScreen(
              transaction: TransactionModel(
                type: 'loan_given',
                category: 'Loan Given',
                account: '',
                note: '',
                amount: 0,
                date: DateTime.now(),
                personId: person.paylioId ?? person.id,
              ),
            )),
          );
        },
        label: const Text('Lend Money'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildHeader(Map<String, double> summary, double netBalance, String currency, NumberFormat format) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: const BoxDecoration(
        color: Color(0xFF0F766E),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(32),
          bottomRight: Radius.circular(32),
        ),
      ),
      child: Column(
        children: [
          Text(
            netBalance == 0 ? 'Settled' : netBalance > 0 ? 'Contact Owes You' : 'You Owe Contact',
            style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 14),
          ),
          const SizedBox(height: 8),
          Text(
            '$currency ${format.format(netBalance.abs())}',
            style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _summaryItem('Lent', summary['lent']! - summary['repaidReceived']!, Colors.white),
              Container(width: 1, height: 30, color: Colors.white.withOpacity(0.3)),
              _summaryItem('Borrowed', summary['borrowed']! - summary['repaidPaid']!, Colors.white),
            ],
          ),
        ],
      ),
    );
  }

  Widget _summaryItem(String label, double amount, Color color) {
    return Column(
      children: [
        Text(label, style: TextStyle(color: color.withOpacity(0.8), fontSize: 12)),
        const SizedBox(height: 4),
        Text(NumberFormat('#,##0').format(amount), style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16)),
      ],
    );
  }

  Widget _buildTransactionCard(BuildContext context, TransactionModel tx, String currency, NumberFormat format) {
    final type = tx.type.toLowerCase();
    final isPositive = type == 'lend' || type == 'loan_given' || type == 'repayment_paid' || type == 'repayment_sent';
    
    IconData icon;
    Color color;
    if (type.contains('repayment')) {
      icon = Icons.sync;
      color = Colors.teal;
    } else if (type == 'lend' || type == 'loan_given') {
      icon = Icons.arrow_upward;
      color = Colors.orange;
    } else {
      icon = Icons.arrow_downward;
      color = Colors.brown;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => AddExpenseScreen(transaction: tx)));
        },
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        title: Row(
          children: [
            Expanded(child: Text(tx.note.isEmpty ? tx.type.replaceAll('_', ' ').toUpperCase() : tx.note, style: const TextStyle(fontWeight: FontWeight.bold))),
            if (tx.status == 'pending' || tx.status == 'pending_approval')
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(4)),
                child: const Text('PENDING', style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: Colors.grey)),
              ),
          ],
        ),
        subtitle: Text(DateFormat('dd MMM yyyy').format(tx.date)),
        trailing: Text(
          '${isPositive ? '+' : '-'} $currency ${format.format(tx.amount)}',
          style: TextStyle(
            color: isPositive ? Colors.green : Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
