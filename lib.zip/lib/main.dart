import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'Core/settings_provider.dart';
import 'Core/theme_data.dart';
import 'Features/Auth/auth_gate.dart';
import 'Features/Auth/auth_provider.dart' as paylio_auth;
import 'Features/Accounts/account_provider.dart';
import 'Features/Transactions/transaction_provider.dart';
import 'Features/Budgets/budget_provider.dart';
import 'Features/Categories/category_provider.dart';
import 'Features/People/person_provider.dart';
import 'Features/Commitments/commitment_provider.dart';

import 'Features/Transactions/shared_transaction_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Global Error Handling
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    debugPrint("Flutter Error: ${details.exception}");
    debugPrintStack(stackTrace: details.stack);
  };

  try {
    // Initialize Firebase and await it to prevent [core/no-app] error
    await Firebase.initializeApp();
    debugPrint("Firebase initialized successfully");
  } catch (e) {
    debugPrint("Firebase initialization failed: $e");
    // If Firebase fails, we still want to see the error in the app if possible
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
        ChangeNotifierProvider(create: (_) => paylio_auth.PaylioAuthProvider()),
        ChangeNotifierProvider(create: (_) => AccountProvider()),
        ChangeNotifierProvider(create: (_) => TransactionProvider()),
        ChangeNotifierProvider(create: (_) => BudgetProvider()),
        ChangeNotifierProvider(create: (_) => CategoryProvider()),
        ChangeNotifierProxyProvider<paylio_auth.PaylioAuthProvider, PersonProvider>(
          create: (context) => PersonProvider(),
          update: (context, auth, person) {
            person?.updateUserId(auth.user?.paylioId);
            return person ?? PersonProvider();
          },
        ),
        ChangeNotifierProxyProvider<paylio_auth.PaylioAuthProvider, SharedTransactionProvider>(
          create: (context) => SharedTransactionProvider(),
          update: (context, auth, shared) {
            shared?.updateUserId(auth.user?.paylioId);
            return shared ?? SharedTransactionProvider();
          },
        ),
        ChangeNotifierProvider(create: (_) => CommitmentProvider()),
      ],
      child: const PaylioApp(),
    ),
  );
}

class PaylioApp extends StatelessWidget {
  const PaylioApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = Provider.of<SettingsProvider>(context);
    
    ThemeData theme;
    switch (settings.appTheme) {
      case 'Modern Paylio':
        theme = AppThemes.getModernPaylio();
        break;
      case 'Dark Money App':
        theme = AppThemes.getDarkMoneyApp();
        break;
      case 'Premium Finance':
      default:
        theme = AppThemes.getPremiumFinance();
        break;
    }

    return MaterialApp(
      title: 'Paylio',
      debugShowCheckedModeBanner: false,
      theme: theme,
      home: const AuthGate(),
    );
  }
}
